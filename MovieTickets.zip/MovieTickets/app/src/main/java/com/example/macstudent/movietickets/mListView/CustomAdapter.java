package com.example.macstudent.movietickets.mListView;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.macstudent.movie.R;
import com.example.macstudent.movie.mData.Movie;
import com.example.macstudent.movie.mDetail.DetilActivity;

import java.util.ArrayList;

public class CustomAdapter extends BaseAdapter {

    Context c;
    ArrayList<Movie> movis;
    LayoutInflater inflater;

    public CustomAdapter(Context c, ArrayList<Movie> movies) {
        this.c = c;
        this.movis= movies;

        inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return movis.size();
    }

    @Override
    public Object getItem(int position) {

        return movis.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {
        if(view == null)
        {
            view = inflater.inflate(R.layout.movies,viewGroup,false );
        }

        TextView txtname =(TextView) view.findViewById(R.id.txtname);
        ImageView img = (ImageView) view.findViewById(R.id.movieImage);

        final String name = movis.get(position).getName();
        final int image = movis.get(position).getImage();

        //BIND DATA
        txtname.setText(name);
        img.setImageResource(image);

        //ITEMCLICK

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDetailActivity(name, image);
            }
        });
        return view;

    }
    //OPEN DETAIL ACTIVITY AND PASS DATA
    private void openDetailActivity(String name,int image)
    {
        Intent i = new Intent(c, DetilActivity.class);
        //PACK DATA
        i.putExtra("NAME_KEY", name);
        i.putExtra("IMAGE_KEY", image);

        //OPEN ACTIVITY
        c.startActivity(i);
    }
}

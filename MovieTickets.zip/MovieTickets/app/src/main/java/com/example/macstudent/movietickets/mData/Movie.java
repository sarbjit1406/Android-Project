package com.example.macstudent.movietickets.mData;

public class Movie {

    String name;
    int image;

    public Movie() {


    }

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public int getImage() {

        return image;
    }

    public void setImage(int image) {

        this.image = image;
    }
}

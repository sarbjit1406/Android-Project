package com.example.macstudent.movietickets.mData;

import com.example.macstudent.movietickets.R;
import com.example.macstudent.movietickets.R;

import java.util.ArrayList;

public class MovieCollection {

    public static ArrayList<Movie> getmovis() {
        ArrayList<Movie> movis = new ArrayList<>();
        Movie movie = null ;

        //ADD DATA TO COLLECTION
        movie = new Movie();
        movie.setName("Aiyaary");
        movie.setImage(R.drawable.aiyaar);
        movis.add(movie);

        movie = new Movie();
        movie.setName("Blackmail");
        movie.setImage(R.drawable.blackmail);
        movis.add(movie);

        movie = new Movie();
        movie.setName("Dhadak");
        movie.setImage(R.drawable.dhadak);
        movis.add(movie);


        movie = new Movie();
        movie.setName("Drishyam");
        movie.setImage(R.drawable.drishyam);
        movis.add(movie);

        movie = new Movie();
        movie.setName("Hichki");
        movie.setImage(R.drawable.hichki);
        movis.add(movie);

        movie = new Movie();
        movie.setName("Nmovie");
        movie.setImage(R.drawable.nmovie);
        movis.add(movie);


        movie = new Movie();
        movie.setName("Not_Out");
        movie.setImage(R.drawable.not_out);
        movis.add(movie);

        movie = new Movie();
        movie.setName("October");
        movie.setImage(R.drawable.october);
        movis.add(movie);

        movie = new Movie();
        movie.setName("Pari");
        movie.setImage(R.drawable.pari);
        movis.add(movie);


        movie = new Movie();
        movie.setName("Raazi");
        movie.setImage(R.drawable.raazi);
        movis.add(movie);

        movie = new Movie();
        movie.setName("Race");
        movie.setImage(R.drawable.race);
        movis.add(movie);

        movie = new Movie();
        movie.setName("Raid");
        movie.setImage(R.drawable.raid);
        movis.add(movie);

        //RETURN COOLLECTION
        return movis;
    }
}


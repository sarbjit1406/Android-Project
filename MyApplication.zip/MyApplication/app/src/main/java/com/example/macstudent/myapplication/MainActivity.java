package com.example.macstudent.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ListView mlistView;
    int[] images ={R.drawable.blackmail, R.drawable.nmovie,
            R.drawable.aiyaary , R.drawable.hichki, R.drawable.pari, R.drawable.raazi,
            R.drawable.race, R.drawable.raid, R.drawable.sanju, R.drawable.veere_di_weeding,
            R.drawable.october};
    String[] Names = {"Blackmail", "1921", "Aiyaary", "Hichki", "Pari",
                     "Raazi", "Race 3", "Raid", "Sanju", "Veere Di Weeding", "October"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mlistView = findViewById(R.id.listView);
        customAdapter customAdapter = new customAdapter();

        mlistView.setAdapter(customAdapter);
    }
    class customAdapter extends BaseAdapter{

        @Override
        public int getCount() {
            return images.length;
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int position, View convertview, ViewGroup viewGroup parent) {
            View view = getLayoutInflater().inflate(R.layout.customlayout , null);
            ImageView mimageView = (ImageView) view.findViewById(R.id.imageView);
            TextView mtextView = view.findViewById(R.id.textView);

            mimageView.setImageResource(images[position]);
            mtextView.setText(Names[position]);
            return view;
        }
    }
}

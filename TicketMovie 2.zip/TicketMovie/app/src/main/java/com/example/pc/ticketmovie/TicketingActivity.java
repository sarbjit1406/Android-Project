package com.example.pc.ticketmovie;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class TicketingActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    EditText edtCinemaPresents;
    TextView txtPrice, txtDateTime;
    Spinner spnMovieTitle, spnTheatre, spnPayment;
    Button btnBookTicket;
    RadioButton rdoOne, rdoTwo, rdoThree;

    int Price[] = {5,7,8};
    String[] theatre = {"Albion Mall","Royal Alexandra"};
    String[] paymentMethods = {"Credit Card", "Debit Card", "Master Card", "American Express"};
    String[] movieNames = {"Aiyaary", "Blackmail", "Dhadak", "Drishyam", "Hichki",
                           "1921", "Not Out", "October", "Pari", "Raazi"};
    int[] logos = {R.drawable.aiyaary, R.drawable.blackmail, R.drawable.dhadak,
            R.drawable.drishyam, R.drawable.hichki,R.drawable.nmovie, R.drawable.not_out,
            R.drawable.october, R.drawable.pari, R.drawable.raazi};

    String selectedTheatre, selectedPayment, selectedMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticketing);

        edtCinemaPresents = findViewById(R.id.edtCinemaPresents);

        txtPrice = findViewById(R.id.txtPrice);
        txtPrice.setText("$" + Price[0]);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(Calendar.getInstance().getTime().toString());

        btnBookTicket = findViewById(R.id.btnBookTicket);
        btnBookTicket.setOnClickListener(this);

        rdoOne = findViewById(R.id.rdoOne);
        rdoOne.setOnClickListener(this);

        rdoTwo = findViewById(R.id.rdoTwo);
        rdoTwo.setOnClickListener(this);

        rdoThree = findViewById(R.id.rdoThree);
        rdoThree.setOnClickListener(this);

        spnTheatre = findViewById(R.id.spnTheatre);
        ArrayAdapter lotAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, theatre);
        spnTheatre.setAdapter(lotAdapter);
        spnTheatre.setOnItemSelectedListener(this);

        spnPayment = findViewById(R.id.spnPayment);
        ArrayAdapter paymentAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, paymentMethods);
        spnPayment.setAdapter(paymentAdapter);
        spnPayment.setOnItemSelectedListener(this);

        spnMovieTitle = findViewById(R.id.spnMovieTitle);
        MovieTitleAdapter movieAdapter = new MovieTitleAdapter(getApplicationContext(), logos, movieNames);
        spnMovieTitle.setAdapter(movieAdapter);
        spnMovieTitle.setOnItemSelectedListener(this);


    }

    @Override
    public void onClick(View view) {
        if(view.getId() == rdoOne.getId()){
            txtPrice.setText("$" + Price[0]);
        } else if(view.getId() == rdoTwo.getId()){
            txtPrice.setText("$" + Price[1]);
        }else if(view.getId() == rdoThree.getId()){
            txtPrice.setText("$" + Price[2]);
        }
        if(view.getId() == btnBookTicket.getId()) {
            SharedPreferences sp = getSharedPreferences("com.example.pc.ticketmovie", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();

            edit.putString("Cinema Presents", edtCinemaPresents.getText().toString());
            edit.putString("DateTime", txtDateTime.getText().toString());
            edit.putString("Theatre", selectedTheatre);
            edit.putString("Movie", selectedMovie);
            edit.putInt("Price",
                    Integer.parseInt(txtPrice.getText().toString().substring(1)));

            edit.commit();

            startActivity(new Intent(getApplicationContext(), TicketActivity.class));

        }

    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        if (adapterView.getId() == spnTheatre.getId()){
            selectedTheatre = theatre[position];
        }else if (adapterView.getId() == spnPayment.getId()){
            selectedPayment = paymentMethods[position];
        }else if (adapterView.getId() == spnMovieTitle.getId()){
            selectedMovie = movieNames[position];
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}

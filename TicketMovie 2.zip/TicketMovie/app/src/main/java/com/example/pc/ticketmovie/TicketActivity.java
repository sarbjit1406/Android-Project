package com.example.pc.ticketmovie;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.pc.ticketmovie.R;

public class TicketActivity extends AppCompatActivity {

    TextView txtCinemaPresents, txtPrice, txtDateTime, txtTheatre, txtMovie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ticket);

        SharedPreferences sp = getSharedPreferences("com.example.pc.ticketmovie", Context.MODE_PRIVATE);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(sp.getString("DateTime","Data Missing"));

        txtCinemaPresents = findViewById(R.id.txtCinemaPresents);
        txtCinemaPresents.setText(sp.getString("Cinema Presents", "Data Missing"));

        txtTheatre = findViewById(R.id.txtTheatre);
        txtTheatre.setText("Theatre: " + sp.getString("Theatre", "Data Missing"));

        txtMovie = findViewById(R.id.txtMovie);
        txtMovie.setText("Movie: " + sp.getString("Movie", "Data Missing"));

        txtPrice = findViewById(R.id.txtPrice);
        txtPrice.setText("$" + String.valueOf(sp.getInt("Price",0)));

    }
}

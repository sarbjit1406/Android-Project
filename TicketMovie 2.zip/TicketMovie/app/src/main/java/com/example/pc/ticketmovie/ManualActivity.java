package com.example.pc.ticketmovie;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

import com.example.pc.ticketmovie.R;

public class ManualActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);

        WebView webManual = findViewById(R.id.webManual);
//        webManual.loadUrl("http://www.google.com");
//        webManual.loadUrl("http://www.google.com/search?q=Albion Centre");
        webManual.loadUrl("file:///android_asset/TicketManual.html");
    }
}


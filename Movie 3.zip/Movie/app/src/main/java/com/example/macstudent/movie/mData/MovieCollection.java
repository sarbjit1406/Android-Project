package com.example.macstudent.movie.mData;

import java.util.ArrayList;

public class MovieCollection {

    public static ArrayList<Movie> getmovies() {
        ArrayList<Movie> movies = new ArrayList<>();
        Movie movie = null;

        //ADD DATA TO COLLECTION
        movie = new Movie();
        movie.setName("aiyaary");
        movie.setImage(R.drawable.aiyaary);
        movies.add(movie);

        movie = new Movie();
        movie.setName("blackmail");
        movie.setImage(R.drawable.blackmail);
        movies.add(movie);

        movie = new Movie();
        movie.setName("dhadak");
        movie.setImage(R.drawable.dhadak);
        movies.add(movie);


        movie = new Movie();
        movie.setName("drishyam");
        movie.setImage(R.drawable.drishyam);
        movies.add(movie);

        movie = new Movie();
        movie.setName("hichki");
        movie.setImage(R.drawable.hichki);
        movies.add(movie);

        movie = new Movie();
        movie.setName("nmovie");
        movie.setImage(R.drawable.nmovie);
        movies.add(movie);


        movie = new Movie();
        movie.setName("not_out");
        movie.setImage(R.drawable.not_out);
        movies.add(movie);

        movie = new Movie();
        movie.setName("october");
        movie.setImage(R.drawable.october);
        movies.add(movie);

        movie = new Movie();
        movie.setName("pari");
        movie.setImage(R.drawable.pari);
        movies.add(movie);


        movie = new Movie();
        movie.setName("raazi");
        movie.setImage(R.drawable.raazi);
        movies.add(movie);

        movie = new Movie();
        movie.setName("race");
        movie.setImage(R.drawable.race);
        movies.add(movie);

        movie = new Movie();
        movie.setName("raid");
        movie.setImage(R.drawable.raid);
        movies.add(movie);

        //return collection
        return movies;
    }
}


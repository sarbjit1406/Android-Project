package com.example.pc.ticketmovie;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pc.ticketmovie.R;

public class ReportAdapter extends BaseAdapter {

    LayoutInflater inflater;
    Context context;

    String[] cinemapresents = {"Cinema Presents", "Cinema Presents"};
    String[] price = {"$8", "$10"};
    String[] theatre = {"Albion Mall","Royal Alexandra"};
    String[] movie = {"Pari", "Raazi"};
    String[] dateTime = {"07-08-2018 04:16 PM", "07-08-2018 6:30 PM"};

    ReportAdapter(Context context){
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return cinemapresents.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(final int position, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.list_report_item, null);

        TextView txtCarPlate = view.findViewById(R.id.txtCinemaPresents);
        txtCarPlate.setText(cinemapresents[position]);

        TextView txtAmount = view.findViewById(R.id.txtPrice);
        txtAmount.setText("$" + price[position]);

        TextView txtDateTime = view.findViewById(R.id.txtDateTime);
        txtDateTime.setText(dateTime[position]);

        TextView txtLot = view.findViewById(R.id.txtTheatre);
        txtLot.setText("Theatre: " + theatre[position]);

        TextView txtSpot = view.findViewById(R.id.txtMovie);
        txtSpot.setText("Movie: " + movie[position]);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context, "Item " + position +
                        " selected", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}

